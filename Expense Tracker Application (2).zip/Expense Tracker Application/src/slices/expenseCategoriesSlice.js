import { createSlice } from '@reduxjs/toolkit';

const expenseCategoriesSlice = createSlice({
  name: 'expenseCategories',
  initialState: { categories: [] }, 
  reducers: {
    addExpenseCategory: (state, action) => {
      state.categories.push({ id: Date.now(), name: action.payload });
    },
    editExpenseCategory: (state, action) => {
      const category = state.categories.find((c) => c.id === action.payload.id);
      if (category) {
        category.name = action.payload.name;
      }
    },
    deleteExpenseCategory: (state, action) => {
      state.categories = state.categories.filter((category) => category.id !== action.payload);
    },
  },
});

export const { addExpenseCategory, editExpenseCategory, deleteExpenseCategory } = expenseCategoriesSlice.actions;
export const selectExpenseCategories = (state) => state.expenseCategories;

export default expenseCategoriesSlice.reducer;
