import { createSlice } from '@reduxjs/toolkit';

const registeredUsers = [
  { username: 'demo', password: 'password'},
];

export const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: null,
    isAuthenticated: false,
    error: null,
  },
  reducers: {
    loginUser: (state, action) => {
     
      const matchingUser = registeredUsers.find(
        (user) =>
          user.username === action.payload.username && user.password === action.payload.password 
          
      );

      if (matchingUser) {
        state.user = { username: matchingUser.username };
        state.isAuthenticated = true;
        state.error = null;
      } else {        
        state.user = null;
        state.isAuthenticated = false;
        state.error = 'Invalid credentials';
      }
    },
    logoutUser: (state) => {
      state.user = null;
      state.isAuthenticated = false;
      state.error = null;
    },
    registerUser: (state, action) => {
      registeredUsers.push({
        username: action.payload.username,
        password: action.payload.password,
      });

      state.user = { username: action.payload.username , email: action.payload.email};
      state.isAuthenticated = true;
      state.error = null;
    },
  },
});

export const { loginUser, logoutUser, registerUser } = authSlice.actions;
export const selectUser = (state) => state.auth.user;
export const selectIsAuthenticated = (state) => state.auth.isAuthenticated;

export default authSlice.reducer;
