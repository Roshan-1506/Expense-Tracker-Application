import { createSlice } from '@reduxjs/toolkit';

const financeSlice = createSlice({
  name: 'finance',
  initialState: {
    income: 0,
    expenses: [],
    balance: 0,
  },
  reducers: {
    addIncome: (state, action) => {
      console.log(action.payload)
      state.income += action.payload.amount;
      state.balance += action.payload.amount;
    },
    addExpense: (state, action) => {
      console.log(action.payload)
      state.expenses.push(action.payload);
      state.balance -= action.payload.amount;
    },
    removeExpense: (state, action) => {
      const index = state.expenses.findIndex((expense) => expense.id === action.payload);
      if (index !== -1) {
        const removedExpense = state.expenses.splice(index, 1)[0];
        state.balance += removedExpense.amount;
      }
    },
    
    updateExpense: (state, action) => {
      const index = state.expenses.findIndex((expense) => expense.id === action.payload.id);
      if (index !== -1) {
       
        state.expenses[index] = action.payload;
      }
    },
   
  },
});

export const { addIncome, addExpense, removeExpense, updateExpense } = financeSlice.actions;
export const selectIncome = (state) => state.finance.income;
export const selectExpenses = (state) => state.finance.expenses;
export const selectBalance = (state) => state.finance.balance;

export default financeSlice.reducer;
