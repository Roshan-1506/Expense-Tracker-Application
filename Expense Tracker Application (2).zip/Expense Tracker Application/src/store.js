import { configureStore } from '@reduxjs/toolkit';
import rootReducer from './rootReducer'; 
import expenseCategoriesReducer from './slices/expenseCategoriesSlice'; 
import financeReducer from './slices/financeSlice';
import authReducer from './slices/authSlice';

export const store = configureStore({
  reducer: {
    ...rootReducer,
    finance: financeReducer,
    expenseCategories: expenseCategoriesReducer,
    auth : authReducer,
  },
});

export default store;
