import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Registration from './components/Registration';
import Dashboard from './components/Dashboard';
import ExpenseList from './components/ExpenseList';
import IncomeForm from './components/IncomeForm';
import ExpenseCategories from './components/ExpenseCategories';
import Statistics from './components/Statistics'; 
import Profile from './components/Profile';

import { useSelector } from 'react-redux';
import { selectIsAuthenticated } from './slices/authSlice';
import './styles.css';

const App = () => {
  const isAuthenticated = useSelector(selectIsAuthenticated);
  return (
    <Router>
      <Routes>
      {isAuthenticated ? (
          <Route path="/" element={<Login />} />
        ) : (
          <>
            <Route path="/login" element={<Login />} />
            <Route path="/registration" element={<Registration />} />
          </>
        )}
        <Route path="/" element={<Login />} /> 
        <Route path="/login" element={<Login />} /> 
        <Route path="/registration" element={<Registration />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/expense-list" element={<ExpenseList />} />
        <Route path="/income" element={<IncomeForm />} />
        <Route path="/expense-categories" element={<ExpenseCategories />} />
        <Route path="/statistics" element={<Statistics />} /> 
        <Route path="/profile" element={<Profile />} />
        
      </Routes>
    </Router>
  );
};

export default App;
