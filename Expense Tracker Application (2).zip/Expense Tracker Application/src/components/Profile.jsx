import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { selectUser, logoutUser } from '../slices/authSlice';

const Profile = () => {
  const user = useSelector(selectUser);
  const email = useSelector(selectUser);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    console.log("User" , user)
    console.log("email" , email)
   
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  const handleLogout = () => {
    dispatch(logoutUser());
    navigate('/login');
  };

  return (
    <div className="container">
      <h2>Profile</h2>
      {user && email ? (
        <>
          <p>Username: {user.username}</p>
        </>
      ) : (
        <p>No profile information available</p>
      )}
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Profile;



