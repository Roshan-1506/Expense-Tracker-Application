import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addExpense, removeExpense, updateExpense } from '../slices/financeSlice';
import { selectExpenses } from '../slices/financeSlice';
import { Link } from 'react-router-dom';
import '../styles.css';

const ExpenseList = () => {
  const dispatch = useDispatch();
  const expenses = useSelector(selectExpenses);
  const [newExpense, setNewExpense] = useState({
    id: null,
    description: '',
    amount: '',
    date: new Date().toISOString().slice(0, 10),
  });

  const handleInputChange = (e) => {
    setNewExpense({
      ...newExpense,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddExpense = () => {
    if (newExpense.description && newExpense.amount) {
      const amount = parseFloat(newExpense.amount);
      if (!isNaN(amount)) {
        if (newExpense.id) {
          dispatch(updateExpense(newExpense));
        } else {
          const id = expenses.length + 1; 
          dispatch(addExpense({ ...newExpense, amount, id }));
        }
        setNewExpense({ id: null, description: '', amount: '', date: new Date().toISOString().slice(0, 10) });
      } else {
        alert('Invalid amount. Please enter a valid number.');
      }
    }
  };

  const handleDeleteExpense = (expenseId) => {
    dispatch(removeExpense(expenseId));
  };

  const handleEditExpense = (expense) => {
    setNewExpense(expense);
  };

  return (
    <div className="expense-list-container">
      <h2>Expense List</h2>
      <table className="expense-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Expense Name</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {expenses.map((expense) => (
            <tr key={expense.id}>
              <td>{expense.id}</td>
              <td>{expense.description}</td>
              <td>${expense.amount}</td>
              <td>{expense.date}</td>
              <td>
                <button className="edit-button" onClick={() => handleEditExpense(expense)}>
                  Edit
                </button>
                <button className="delete-button" onClick={() => handleDeleteExpense(expense.id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="add-expense-form">
        <h3>{newExpense.id ? 'Edit Expense' : 'Add New Expense'}</h3>
        <div className="input-container">
          <label>Expense Name:</label>
          <input
            type="text"
            name="description"
            value={newExpense.description}
            onChange={handleInputChange}
          />
        </div>
        <div className="input-container">
          <label>Amount:</label>
          <input
            type="text"
            name="amount"
            value={newExpense.amount}
            onChange={handleInputChange}
          />
        </div>
        <button className="add-expense-btn" onClick={handleAddExpense}>
          {newExpense.id ? 'Save Expense' : 'Add Expense'}
        </button>
        <Link to="/dashboard" className="dashboard-button">
          Dashboard
        </Link>
      </div>
    </div>
  );
};

export default ExpenseList;
