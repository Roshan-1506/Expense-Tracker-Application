import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  addExpenseCategory,
  editExpenseCategory,
  deleteExpenseCategory,
  selectExpenseCategories,
} from '../slices/expenseCategoriesSlice';
import {
  selectIncome,
  selectExpenses,
  selectBalance,
} from '../slices/financeSlice';
import { Link } from 'react-router-dom'; 
import '../styles.css';

const ExpenseCategories = () => {
  const dispatch = useDispatch();
  const { categories } = useSelector(selectExpenseCategories);
  const income = useSelector(selectIncome);
  const expenses = useSelector(selectExpenses);
  const balance = useSelector(selectBalance);
  const [newCategory, setNewCategory] = useState('');
  const [editingCategoryId, setEditingCategoryId] = useState(null);

  const handleAddCategory = () => {
    if (newCategory.trim()) {
      dispatch(addExpenseCategory(newCategory.trim()));
      setNewCategory('');
    }
  };

  const handleEditCategory = (categoryId, newName) => {
    dispatch(editExpenseCategory({ id: categoryId, name: newName }));
    setEditingCategoryId(null);
  };

  const handleDeleteCategory = (categoryId) => {
    dispatch(deleteExpenseCategory(categoryId));
    setEditingCategoryId(null);
  };

  const generateUniqueId = () => {
    return categories.length + 1; 
  };

  return (
    <div className="expense-categories-container">
      <div className="expense-categories">
        <h2>Expense Categories</h2>
        <table>
          <tbody>
            <tr>
              <td>Income:</td>
              <td>${income}</td>
            </tr>
            <tr>
              <td>Expenses:</td>
              <td>${expenses.reduce((total, expense) => total + expense.amount, 0)}</td>
            </tr>
            <tr>
              <td>Balance:</td>
              <td>${balance}</td>
            </tr>
          </tbody>
        </table>
        <div className="category-list">
          <h3>Category List</h3>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((category, index) => (
                <tr key={category.id}>
                  <td>{index + 1}</td> 
                  <td>
                    {editingCategoryId === category.id ? (
                      <input
                        type="text"
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value)}
                        placeholder="Category Name"
                      />
                    ) : (
                      category.name
                    )}
                  </td>
                  <td>{new Date().toISOString().slice(0, 10)}</td> 
                  <td>
                    {editingCategoryId === category.id ? (
                      <button
                        className="edit-btn"
                        onClick={() => handleEditCategory(category.id, newCategory)}
                      >
                        Save
                      </button>
                    ) : (
                      <>
                        <button
                          className="edit-btn edit-color"
                          onClick={() => setEditingCategoryId(category.id)}
                        >
                          Edit
                        </button>
                        <button
                          className="delete-btn delete-color"
                          onClick={() => handleDeleteCategory(category.id)}
                        >
                          Delete
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="add-category">
          <input
            type="text"
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            placeholder="Category Name"
          />
          <button className="add-btn" onClick={handleAddCategory}>
            Add Category
          </button>
          <Link to="/dashboard" className="dashboard-button">
            Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ExpenseCategories;
