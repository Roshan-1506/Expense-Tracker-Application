import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { registerUser } from '../slices/authSlice';
import '../styles.css';

const Registration = () => {
  const [userData, setUserData] = useState({ username: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleInputChange = (e) => {
    setUserData({ ...userData, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: '' });
  };

  const validateForm = () => {
    let valid = true;
    const newErrors = {};

    if (!userData.username.trim()) {
      valid = false;
      newErrors.username = 'Username is required';
    }

    if (!userData.email.trim()) {
      valid = false;
      newErrors.email = 'Email is required';
    }

    if (!userData.password.trim()) {
      valid = false;
      newErrors.password = 'Password is required';
    }

    setErrors(newErrors);
    return valid;
  };

  const handleRegistration = async () => {
    if (validateForm()) {
      try {       
        dispatch(registerUser(userData));
        navigate('/login');
      } catch (error) {
        console.error('Registration failed:', error);
      }
    }
  };

  return (
    <div className="container">
      <h2>Registration</h2>
      <div className="form-group">
        <label>Username</label>
        <input type="text" name="username" onChange={handleInputChange} />
        {errors.username && <p style={{ color: 'red' }}>{errors.username}</p>}
      </div>
      <div className="form-group">
        <label>Email</label>
        <input type="email" name="email" onChange={handleInputChange} />
        {errors.email && <p style={{ color: 'red' }}>{errors.email}</p>}
      </div>
      <div className="form-group">
        <label>Password</label>
        <input type="password" name="password" onChange={handleInputChange} />
        {errors.password && <p style={{ color: 'red' }}>{errors.password}</p>}
      </div>
      <div className="form-group">
        <button onClick={handleRegistration}>Register</button>
      </div>
    </div>
  );
};

export default Registration;

