import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addIncome } from '../slices/financeSlice';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectIncome } from '../slices/financeSlice';
import '../styles.css';

const IncomeForm = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [incomeData, setIncomeData] = useState({
    source: '',
    amount: '',
  });

  const [incomeList, setIncomeList] = useState([]);
  const [idCounter, setIdCounter] = useState(1); 

  const dashboardIncome = useSelector(selectIncome);

  const handleInputChange = (e) => {
    setIncomeData({
      ...incomeData,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddIncome = () => {
    if (incomeData.source && incomeData.amount) {
      const amount = parseFloat(incomeData.amount);

      if (!isNaN(amount)) {
        const newIncome = {
          id: idCounter, // Assign ID
          source: incomeData.source,
          amount: amount,
          date: new Date().toLocaleDateString(), // Generate date
        };

        dispatch(addIncome(newIncome));
        setIncomeList([...incomeList, newIncome]);
        setIdCounter(idCounter + 1); // Increment ID counter
        setIncomeData({ source: '', amount: '' });
      } else {
        alert('Invalid amount. Please enter a valid number.');
      }
    }
  };

  return (
    <div className="income-form-container">
      <h2>Add Income</h2>
      <div className="income-form">
        <label>Source:</label>
        <input
          type="text"
          name="source"
          value={incomeData.source}
          onChange={handleInputChange}
        />
        <label>Amount:</label>
        <input
          type="text"
          name="amount"
          value={incomeData.amount}
          onChange={handleInputChange}
        />
        <button className="add-income-btn" onClick={handleAddIncome}>
          Add Income
        </button>
      </div>
      {incomeList.length > 0 && (
        <div className="income-list">
          <h3>Income List</h3>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Source</th>
                <th>Amount</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {incomeList.map((income) => (
                <tr key={income.id}>
                  <td>{income.id}</td>
                  <td>{income.source}</td>
                  <td>${income.amount}</td>
                  <td>{income.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {incomeList.length > 0 && (
        <div className="dashboard-button-container">
          <button className="dashboard-button" onClick={() => navigate('/dashboard')}>
            Go to Dashboard
          </button>
        </div>
      )}
    </div>
  );
};

export default IncomeForm;
