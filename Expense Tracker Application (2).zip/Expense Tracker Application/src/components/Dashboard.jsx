import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { selectIncome, selectExpenses, selectBalance } from '../slices/financeSlice';
import '../styles.css';

const Dashboard = () => {
  const income = useSelector(selectIncome);
  const expenses = useSelector(selectExpenses);
  const balance = useSelector(selectBalance);
 
  const totalExpense = expenses.reduce((total, expense) => total + parseFloat(expense.amount), 0);

  return (
    <div className="dashboard-container">
      <h2>Dashboard</h2>
      <div className="dashboard-summary">
        <table>
          <tbody>
            <tr>
              <td>Income:</td>
              <td>${income}</td>
            </tr>
            <tr>
              <td>Expenses:</td>
              {/* <td>${expenses.reduce((total, expense) => total + expense.amount, 0)}</td> */}
              <td>${totalExpense}</td>
            </tr>
            <tr>
              <td>Balance:</td>
              <td>${balance}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="dashboard-nav">
        <ul>
          <li>
            <Link to="/income" className="dashboard-button">Add Income</Link>
          </li>
          <li>
            <Link to="/expense-list" className="dashboard-button">Expense List</Link>
          </li>
          <li>
            <Link to="/expense-categories" className="dashboard-button">Expense Categories</Link>
          </li>
          <li>
            <Link to="/statistics" className="dashboard-button">Statistics</Link>
          </li>
          <li>
            <Link to="/profile" className="dashboard-button">Go to Profile</Link>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;
