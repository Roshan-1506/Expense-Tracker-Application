import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux'; 
import { loginUser, selectIsAuthenticated } from '../slices/authSlice'; 
import '../styles.css';

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [error, setError] = useState('');

  const isAuthenticated = useSelector(selectIsAuthenticated); 

  const handleInputChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleLogin = () => {
    dispatch(loginUser(credentials));

    if (isAuthenticated) {
      
      navigate('/dashboard');
    } else {
      
      setError('Invalid credentials');
    }
  };

  return (
    <div className="container">
      <h2>Login</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <div className="form-group">
        <label>Username</label>
        <input type="text" name="username" onChange={handleInputChange} />
      </div>

      <div className="form-group">
        <label>Password</label>
        <input type="password" name="password" onChange={handleInputChange} />
      </div>

      <div className="form-group">
        <button onClick={handleLogin}>Login</button>
      </div>

      <div className="form-group">
        <p>
          Don't have an account? <Link to="/registration">Register here</Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
