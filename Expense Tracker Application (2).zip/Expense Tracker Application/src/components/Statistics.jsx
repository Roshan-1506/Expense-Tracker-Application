import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { selectIncome, selectExpenses, selectBalance } from '../slices/financeSlice';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Link } from 'react-router-dom'; 

ChartJS.register(ArcElement, Tooltip, Legend);

const Statistics = () => {
  const income = useSelector(selectIncome);
  const expenses = useSelector(selectExpenses);
  const balance = useSelector(selectBalance);

  useEffect(() => {
    console.log('Income:', income);
    console.log('Expenses:', expenses);
    console.log('Balance:', balance);
  }, [income, expenses, balance]);

  
  const chartDataObject = {
    labels: ['Income', 'Expenses', 'Balance'],
    datasets: [
      {
        data: [income, expenses[0]?.amount || 0, balance],
        backgroundColor: ['#4CAF50', '#FF6384', '#36A2EB'],
        hoverBackgroundColor: ['#4CAF50', '#FF6384', '#36A2EB'],
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
  };

  return (
    <div className="statistics-container">
      <h2 style={{ textAlign: 'center' }}>Statistics</h2>
      <div className="chart-box">
        <Doughnut data={chartDataObject} options={chartOptions} style={{backgroundColor: "white"}} />
      </div>
      <Link to="/dashboard" className="dashboard-button">Dashboard</Link> 
    </div>
  );
};

export default Statistics;
