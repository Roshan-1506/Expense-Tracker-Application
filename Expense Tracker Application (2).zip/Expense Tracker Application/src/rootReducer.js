import { combineReducers } from '@reduxjs/toolkit';
import financeReducer from './slices/financeSlice'; 

const rootReducer = combineReducers({
  finance: financeReducer,
  
});

export default rootReducer;
